enum SearchShortBy {
  newArrivals, offerProducts,
}