enum OrderStatus {
  pending,
  confirmed,
  processing,
  out_for_delivery,
  delivered,
  returned,
  failed,
  canceled,
}