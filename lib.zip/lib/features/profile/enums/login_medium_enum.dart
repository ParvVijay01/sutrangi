enum LoginMedium{
  general, facebook, google
}