enum ProductFilterType {
  highToLow,
  lowToHigh,
}