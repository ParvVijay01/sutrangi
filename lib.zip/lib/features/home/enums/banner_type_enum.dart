enum BannerType{
  primary,
  secondary,
}